/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package steppingstones;

import java.util.Scanner;

/**
 *
 * @author michaelsurdek_snhu
 */
public class SteppingStone2_IngedientCalculator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // initialize variables and scanner
        String nameOfIngredient = "";
        int numberOfCups = 0;
        double numberOfCaloriesPerCup = 0.0;
        double totalCalories = 0.0;
        Scanner scnr = new Scanner(System.in);
        
        // get ingredient name, number of cups, and calories per cup from user
        System.out.println("Please enter the name of the ingredient: ");
        nameOfIngredient = scnr.next();
        
        System.out.println("Please enter the number of cups of " + nameOfIngredient + " that we'll need: ");
        numberOfCups = scnr.nextInt();

        System.out.println("Please enter the number of calories per cup of " + nameOfIngredient + ": ");
        numberOfCaloriesPerCup = scnr.nextFloat();
        
        // calculate total calories in the ingredient
        totalCalories = numberOfCups * numberOfCaloriesPerCup;
        
        // print ingredient details
        System.out.println(numberOfCups + " cups of " + nameOfIngredient + " has " + totalCalories + " calories.");
    }
    
}
