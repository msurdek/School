/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *
 * @author michaelsurdek_snhu
 */

package steppingstones5;

public class Ingredient {
    
    String nameOfIngredient;
    
    public String addNewIngredient(String name) {
        
        // initialize variables to store each ingredient's attributes
        nameOfIngredient = name;           // the name of the ingredient as a seqeuence of characters

        return nameOfIngredient;
    }
}