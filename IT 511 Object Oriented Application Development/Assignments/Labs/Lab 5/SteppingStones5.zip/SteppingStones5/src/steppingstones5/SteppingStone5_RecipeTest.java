/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *
 * @author michaelsurdek_snhu
 */

package steppingstones5;

import java.util.ArrayList;
import steppingstones5.SteppingStone5_Recipe;

public class SteppingStone5_RecipeTest {
    public static void main(String[] args) {
      // create two array lists to store ingredient names
      ArrayList<String> recipeIngredients = new ArrayList();
      ArrayList<String> recipeIngredientsTwo = new ArrayList();
      
      // initialize first recipe
      SteppingStone5_Recipe myFirstRecipe = new SteppingStone5_Recipe();
      
      // create first ingredient name
      String ingredientNameTwo = "Noodles";
      String tempIngredientTwo = new Ingredient().addNewIngredient(ingredientNameTwo);
      // add ingredient to first array list
      recipeIngredients.add(tempIngredientTwo);
      
      // set recipe attributes through mutators
      myFirstRecipe.setRecipeName("Ramen");
      myFirstRecipe.setServings(2);
      myFirstRecipe.setRecipeIngredients(recipeIngredients);
      myFirstRecipe.setTotalRecipeCalories(150);
      
      // initiate second recipe
      // first, create second ingredient name
      String ingredientName = "Anchovies";
      String tempIngredient = new Ingredient().addNewIngredient(ingredientName);
      recipeIngredientsTwo.add(tempIngredient);
      
      // set recipe attributes through constructor
      SteppingStone5_Recipe mySecondRecipe = new SteppingStone5_Recipe("Pizza", 2, recipeIngredientsTwo, 300);
      
      // print details of both recipes
      myFirstRecipe.printRecipe();
      mySecondRecipe.printRecipe();
    }
}
