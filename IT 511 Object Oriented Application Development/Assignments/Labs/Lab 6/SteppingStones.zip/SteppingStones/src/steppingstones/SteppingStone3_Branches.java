/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *
 * 
 * @author michaelsurdek_snhu
 */
package steppingstones;

import java.util.Scanner;

public class SteppingStone3_Branches {

    /**
     * @param args the command line arguments
     */
    public static void branches() {
        
        // initialize variables to store the attributes of this input verification class
        // the number of cups, an integer, set initially to -1 because user input must be between 1 and 100
        int numberCups = -1;
        // the maximum integer number cups that the ingredient can contain for this program 
        final int MAX_CUPS = 100;
        
        // initialize the scanner
        Scanner scnr = new Scanner(System.in);
        
        // ask user for number of cups
        System.out.println("Please enter the number of cups (between 1 and 100): ");
        
        // branch to verify that the input is an integer
        if (scnr.hasNextInt()) {
            numberCups = scnr.nextInt();
            
            // if number of cups is an integer between 1 and 100, else branch is not entered
            if ((numberCups >= 1) & (numberCups <= MAX_CUPS)) {
                System.out.println(numberCups + " is a valid number of cups!");
            }
            
            // else branch prints whether the number of cups is less than 1 or greater than 100 then asks for a second input
            else {
                if (numberCups < 1){
                    System.out.println(numberCups + " is less than 1.");
                }
                
                else {
                    System.out.println(numberCups + " is greater than 100.");
                }
                
                System.out.println("Please enter another number of cups between 1 and 100.");
                
                numberCups = scnr.nextInt();
                
                // the final branch prints whether the second input is a valid integer
                // if it is not, the user is informed they are out of attempts
                if ((numberCups >= 1) & (numberCups <= 100)) {
                    System.out.println(numberCups + " is a valid number of cups!");
                }
                
                else {
                    System.out.println(numberCups + " is not a valid number of cups! Sorry you are out of attempts.");
                }
            }
        }
        
        // if input is not an integer, print the error
        else {
            System.out.println("Error: That is not a number. Try again.");
        }
    }
}
