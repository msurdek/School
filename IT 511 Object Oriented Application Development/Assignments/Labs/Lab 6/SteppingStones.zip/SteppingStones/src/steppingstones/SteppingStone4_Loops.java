/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *
 *
 * @author michaelsurdek_snhu
 */

package steppingstones;

import java.util.Scanner;
import java.util.ArrayList;

public class SteppingStone4_Loops {

    public static void loops() {
        
        Scanner scnr = new Scanner(System.in);                  // for user input
        boolean addMoreIngredients = true;                      // condition for accepting new ingredients from the user
        String newIngredient = "";                              // the name of each new ingredient from the user
        ArrayList<String> ingredientList = new ArrayList();     // a list to store the ingredients of a recipe
        String recipeName = "";                                 // the name of the recipe  for the list of ingredients

        // ask the user for the name of the recipe for which they wish to enter a list of ingredients
        
        System.out.println("Please enter the recipe name: ");
        recipeName = scnr.nextLine();
        
        // ask the user if they wish to enter an ingredient
        
        do {
            System.out.println("Would you like to enter an ingredient: (y or n)");
            String reply = scnr.next().toLowerCase();
            
            // if no, exit the loop            
            // if yes, ask for the name of the ingredient and add it to the list, then ask again
            // otherwise, also ask again
            
            if (reply.length() == 1 & reply.charAt(0) == 'n') {
                addMoreIngredients = false;
            } else if (reply.length() == 1 & reply.charAt(0) == 'y') {
                System.out.println("Please enter the name of the ingredient: ");
                newIngredient = scnr.next();
                ingredientList.add(newIngredient);
            } else {
                System.out.println("Please type 'y' or 'n'.");
            }
            
        } while (addMoreIngredients);
        
        // print the name of the recipe and the list of ingredients
        
        if (ingredientList.size() > 0) {
            System.out.println("Ingredients in " + recipeName + ":");
            
            for (int i = 0; i < ingredientList.size(); ++i) {
                String ingredient = ingredientList.get(i);
                System.out.println((i+1) + ".  " + ingredient);
            }
        }
    }
}
