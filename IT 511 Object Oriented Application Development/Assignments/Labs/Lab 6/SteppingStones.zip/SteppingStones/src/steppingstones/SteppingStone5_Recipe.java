/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *
 *
 * @author michaelsurdek_snhu
 */

package steppingstones;

import java.util.Scanner;
import java.util.ArrayList;

public class SteppingStone5_Recipe {
    
    // declare recipe class attributes
    private String recipeName;                      // name of the recipe
    private int servings;                           // number of people the recipe can serve
    private ArrayList<SteppingStone2_IngedientCalculator> recipeIngredients;    // list of ingredients in the recipe
    private double totalRecipeCalories;             // sum of calories from all ingredients
    
    // create accessor and mutator for each attribute
    /**
     * @return the recipeName
     */
    public String getRecipeName() {
        return recipeName;
    }

    /**
     * @param recipeName the recipeName to set
     */
    public void setRecipeName(String recipeName) {
        this.recipeName = recipeName;
    }

    /**
     * @return the servings
     */
    public int getServings() {
        return servings;
    }

    /**
     * @param servings the servings to set
     */
    public void setServings(int servings) {
        this.servings = servings;
    }

    /**
     * @return the recipeIngredients
     */
    public ArrayList<SteppingStone2_IngedientCalculator> getRecipeIngredients() {
        return recipeIngredients;
    }

    /**
     * @param recipeIngredients the recipeIngredients to set
     */
    public void setRecipeIngredients(ArrayList<SteppingStone2_IngedientCalculator> recipeIngredients) {
        this.recipeIngredients = recipeIngredients;
    }

    /**
     * @return the totalRecipeCalories
     */
    public double getTotalRecipeCalories() {
        return totalRecipeCalories;
    }

    /**
     * @param totalRecipeCalories the totalRecipeCalories to set
     */
    public void setTotalRecipeCalories(double totalRecipeCalories) {
        this.totalRecipeCalories = totalRecipeCalories;
    }      
    
    // create basic constructor
    public SteppingStone5_Recipe() {
        this.recipeName = "";
        this.servings = 0;
        this.recipeIngredients = new ArrayList();
        this.totalRecipeCalories = 0.0;
    }
    
    // create constructor with parameters
    public SteppingStone5_Recipe(String recipeName, int servings,
            ArrayList<SteppingStone2_IngedientCalculator> recipeIngredients, double totalRecipeCalories) {
        this.recipeName = recipeName;
        this.servings = servings;
        this.recipeIngredients = recipeIngredients;
        this.totalRecipeCalories = totalRecipeCalories;
    }
    
    // method to print recipe details
    public void printRecipe() {
        double singleServingCalories;
        singleServingCalories = totalRecipeCalories / servings;
        
        System.out.println("Recipe: " + recipeName);
        System.out.println("Serves: " + servings);
        System.out.println("Ingredients:");
        
        int i;
        for (i = 0; i < recipeIngredients.size(); i = i + 1) {
            System.out.println(recipeIngredients.get(i));
        }
        
        System.out.println("Each serving has " + singleServingCalories + " Calories.");
    }
    
    public static SteppingStone5_Recipe createNewRecipe() {
        // initialize recipe attributes to default values
        String recipeName = "";
        int servings = 0;
        double totalRecipeCalories = 0.0;
        ArrayList<SteppingStone2_IngedientCalculator> recipeIngredients = new ArrayList(); 
        boolean addMoreIngredients = true;
        
        Scanner scnr = new Scanner(System.in);
        
        // ask user for the name of the recipe
        System.out.println("Please enter the recipe name: ");
        recipeName = scnr.nextLine();
        
        // ask the user how many people the recipe serves
        System.out.println("Please enter the number of servings of " + recipeName + ": ");
        servings = scnr.nextInt();
        
        // until the user inputs "end", ask for the ingredient name, measurement amount, and calories per unit
        do {
            SteppingStone2_IngedientCalculator newIngredient = new SteppingStone2_IngedientCalculator();
            newIngredient.addNewIngredient();
            
            recipeIngredients.add(newIngredient);
            
            System.out.println("Do you have another ingredient to add? (y/n)");
            Scanner scnrReply = new Scanner(System.in);
            String reply = scnrReply.nextLine();
            
            if ((reply.length() == 1) & (reply.charAt(0) == 'n')) {
                addMoreIngredients = false;
            }
        } while (addMoreIngredients);
        
        //calculate total calories in the recipe
        int i;
        for (i = 0; i < recipeIngredients.size(); i = i + 1) {
            totalRecipeCalories = totalRecipeCalories + recipeIngredients.get(i).getIngredientAmount() * recipeIngredients.get(i).getCaloriesPerUnit();
        }
        
        // create new recipe based on user input and print the details
        SteppingStone5_Recipe recipe1 = new SteppingStone5_Recipe(recipeName, servings, recipeIngredients, totalRecipeCalories);
        recipe1.printRecipe();
        
        return recipe1;
    }
    
    public static SteppingStone5_Recipe addRecipe() {
        // initialize recipe attributes to default values
        String recipeName = "";
        int servings = 0;
        double totalRecipeCalories = 0.0;
        ArrayList<SteppingStone2_IngedientCalculator> recipeIngredients = new ArrayList(); 
        boolean addMoreIngredients = true;
        
        Scanner scnr = new Scanner(System.in);
        
        // ask user for the name of the recipe
        System.out.println("Please enter the recipe name: ");
        recipeName = scnr.nextLine();
        
        // ask the user how many people the recipe serves
        System.out.println("Please enter the number of servings of " + recipeName + ": ");
        servings = scnr.nextInt();
        
        // until the user inputs "end", ask for the ingredient name, measurement amount, and calories per unit
        do {
            SteppingStone2_IngedientCalculator newIngredient = new SteppingStone2_IngedientCalculator();
            newIngredient.addNewIngredient();
            
            recipeIngredients.add(newIngredient);
            
            System.out.println("Do you have another ingredient to add? (y/n)");
            Scanner scnrReply = new Scanner(System.in);
            String reply = scnrReply.nextLine();
            
            if ((reply.length() == 1) & (reply.charAt(0) == 'n')) {
                addMoreIngredients = false;
            }
        } while (addMoreIngredients);
        
        //calculate total calories in the recipe
        int i;
        for (i = 0; i < recipeIngredients.size(); i = i + 1) {
            totalRecipeCalories = totalRecipeCalories + recipeIngredients.get(i).getIngredientAmount() * recipeIngredients.get(i).getCaloriesPerUnit();
        }
        
        // create new recipe based on user input and print the details
        SteppingStone5_Recipe recipe1 = new SteppingStone5_Recipe(recipeName, servings, recipeIngredients, totalRecipeCalories);
        
        return recipe1;
    }
}
