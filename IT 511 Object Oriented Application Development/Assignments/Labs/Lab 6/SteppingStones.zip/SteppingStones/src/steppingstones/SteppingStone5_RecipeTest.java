/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *
 *
 * @author michaelsurdek_snhu
 */

package steppingstones;

import java.util.ArrayList;

public class SteppingStone5_RecipeTest {

	public static void recipeTest() {
		// Create two recipe objects first
		SteppingStone5_Recipe myFirstRecipe = new SteppingStone5_Recipe();
		ArrayList<SteppingStone2_IngedientCalculator> recipeIngredients = new ArrayList(); 
		ArrayList<SteppingStone2_IngedientCalculator> recipeIngredientsTwo = new ArrayList(); 
		String ingredientName = "Anchovies";
		SteppingStone2_IngedientCalculator tempIngredient = new SteppingStone2_IngedientCalculator().addNewIngredientName(ingredientName);
		recipeIngredients.add(tempIngredient);
      
    	SteppingStone5_Recipe mySecondRecipe = new SteppingStone5_Recipe("Pizza", 2, recipeIngredients, 300);
   	 
    	// Initialize first recipe
		String ingredientNameTwo = "Noodles";
		SteppingStone2_IngedientCalculator tempIngredientTwo = new SteppingStone2_IngedientCalculator().addNewIngredientName(ingredientNameTwo);
		recipeIngredientsTwo.add(tempIngredientTwo);

    	myFirstRecipe.setRecipeName("Ramen");
    	myFirstRecipe.setServings(2);
    	myFirstRecipe.setRecipeIngredients(recipeIngredientsTwo);
    	myFirstRecipe.setTotalRecipeCalories(150);
   	 
    	// Print details of both recipes
    	myFirstRecipe.printRecipe();
    	mySecondRecipe.printRecipe();
	
        // create (and print) third recipe from user input
        SteppingStone5_Recipe myThirdRecipe = SteppingStone5_Recipe.createNewRecipe();
        }
    
}