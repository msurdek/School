package finalproject;

/**
 * Ingredient - class to store details of ingredients that make up a recipe object 
 *
 * @author michaelsurdek_snhu
 */
public class Ingredient {

    // initialize ingredient class attributes
    private String nameOfIngredient;          // the name of the ingredient as a seqeuence of characters
    private String unitMeasurement;           // the type of measurement for the ingredient (cups, ounces, etc.)
    private double ingredientAmount;          // the amount of cups/ounces/etc required
    private double caloriesPerUnit;           // the number of calories in one unit of the ingredient
    private double totalCalories;             // the total calories of the ingredient as a floating point number

    // create accessor and mutator methods for each attribute
    
    /**
     * accessor for nameOfIngredient attribute
     * @return the nameOfIngredient
     */
    public String getNameOfIngredient() {
        return nameOfIngredient;
    }

    /**
     * mutator for nameOfIngredient attribute
     * @param nameOfIngredient the nameOfIngredient to set
     */
    public void setNameOfIngredient(String nameOfIngredient) {
        this.nameOfIngredient = nameOfIngredient;
    }

    /**
     * accessor for unitMeasurement attribute
     * @return the unitMeasurement
     */
    public String getUnitMeasurement() {
        return unitMeasurement;
    }

    /**
     * mutator for unitMeasurement attribute
     * @param unitMeasurement the unitMeasurement to set
     */
    public void setUnitMeasurement(String unitMeasurement) {
        this.unitMeasurement = unitMeasurement;
    }

    /**
     * accessor for ingredientAmount attribute
     * @return the ingredientAmount
     */
    public double getIngredientAmount() {
        return ingredientAmount;
    }

    /**
     * mutator for ingredientAmount attribute
     * @param ingredientAmount the ingredientAmount to set
     */
    public void setIngredientAmount(double ingredientAmount) {
        this.ingredientAmount = ingredientAmount;
    }

    /**
     * accessor for caloriesPerUnit attribute
     * @return the caloriesPerUnit
     */
    public double getCaloriesPerUnit() {
        return caloriesPerUnit;
    }

    /**
     * mutator for caloriesPerUnitattribute
     * @param caloriesPerUnit the caloriesPerUnit to set
     */
    public void setCaloriesPerUnit(double caloriesPerUnit) {
        this.caloriesPerUnit = caloriesPerUnit;
    }

    /**
     * accessor for totalCalories attribute
     * @return the totalCalories
     */
    public double getTotalCalories() {
        return totalCalories;
    }

    /**
     * mutator for totalCalories attribute
     * @param totalCalories the totalCalories to set
     */
    public void setTotalCalories(double totalCalories) {
        this.totalCalories = totalCalories;
    }
        
    // create constructors for ingredient objects
    
    /**
     * basic ingredient constructor with no parameters
     */
    public Ingredient() {
        this.nameOfIngredient = "";
        this.unitMeasurement = "";
        this.ingredientAmount = 0.0;
        this.caloriesPerUnit = 0.0;
        this.totalCalories = 0.0;
    }
    
    /**
     * ingredient constructor with necessary parameters
     * @param nameOfIngredient the name of the ingredient
     * @param unitMeasurement the measurement type of the ingredient
     * @param ingredientAmount the amount of the ingredient
     * @param caloriesPerUnit the calories in each unit of the ingredient
     */
    public Ingredient(String nameOfIngredient, String unitMeasurement, Double ingredientAmount, Double caloriesPerUnit) {
        this.nameOfIngredient = nameOfIngredient;
        this.unitMeasurement = unitMeasurement;
        this.ingredientAmount = ingredientAmount;
        this.caloriesPerUnit = caloriesPerUnit;
        this.totalCalories = ingredientAmount * caloriesPerUnit;
    }
        
    /**
     * method to create a new ingredient from user input
     * @return newIngredient - a completed Ingredient object for a recipe's list of ingredients
     */
    public Ingredient createNewIngredient() {
        
        //initialize temporary attributes
        String tempNameOfIngredient;
        String tempUnitMeasurement;
        double tempIngredientAmount;
        double tempCaloriesPerUnit;
        double tempTotalCalories = 0.0;
        
        // get valid ingredient name from user
        System.out.println("\nPlease enter the name of an ingredient: ");
        tempNameOfIngredient = Validation.getValidIngredientName();
        
        // get valid unit of measurement from user
        System.out.println("\nPlease enter the type of measurement of " + tempNameOfIngredient + ": ");
        System.out.println("Possible measurement types include cups, ounces, teaspoons, etc.");
        tempUnitMeasurement = Validation.getValidUnitMeasurement();

        // get valid ingredient amount from user
        System.out.println("\nPlease enter the amount of " + tempUnitMeasurement + " of " + tempNameOfIngredient + ": ");
        tempIngredientAmount = Validation.getValidIngredientAmount();
        
        // get valid calories per unit from user
        System.out.println("\nPlease enter the number of calories in every 1 " + tempUnitMeasurement + " of " + tempNameOfIngredient + ": ");
        tempCaloriesPerUnit = Validation.getValidCaloriesPerUnit();
        
        // calculate total calories in the ingredient
        // multiply the number of cups of the ingredient by the calories per cup
        tempTotalCalories = tempIngredientAmount * tempCaloriesPerUnit;
        
        // create new ingredient object from parameterized constructor
        Ingredient newIngredient = new Ingredient(tempNameOfIngredient, tempUnitMeasurement, tempIngredientAmount, tempCaloriesPerUnit);
        
        // return the new ingredient object
        return newIngredient;
    }
}