package finalproject;

import java.util.ArrayList;

/**
 * Recipe - class to store recipe details
 *
 * @author michaelsurdek_snhu
 */
public class Recipe {
    
    // initialize recipe class attributes
    private String recipeName;                          // the name of the recipe
    private int servings;                               // the number of people the recipe can serve
    private ArrayList<Ingredient> recipeIngredients;    // am array list of ingredients in the recipe
    private double totalRecipeCalories;                 // the sum of calories from all ingredients
    
    // create accessor and mutator methods for each attribute
    
    /**
     * accessor for recipeName attribute
     * @return the recipeName
     */
    public String getRecipeName() {
        return recipeName;
    }

    /**
     * mutator for recipeName attribute
     * @param recipeName the recipeName to set
     */
    public void setRecipeName(String recipeName) {
        this.recipeName = recipeName;
    }

    /**
     * accessor for servings attribute
     * @return the servings
     */
    public int getServings() {
        return servings;
    }

    /**
     * mutator for servings attribute
     * @param servings the servings to set
     */
    public void setServings(int servings) {
        this.servings = servings;
    }

    /**
     * accessor for recipeIngredients attribute
     * @return the recipeIngredients
     */
    public ArrayList<Ingredient> getRecipeIngredients() {
        return recipeIngredients;
    }

    /**
     * mutator for recipeIngredients attribute
     * @param recipeIngredients the recipeIngredients to set
     */
    public void setRecipeIngredients(ArrayList<Ingredient> recipeIngredients) {
        this.recipeIngredients = recipeIngredients;
    }

    /**
     * accessor for totalRecipeCalories attribute
     * @return the totalRecipeCalories
     */
    public double getTotalRecipeCalories() {
        return totalRecipeCalories;
    }

    /**
     * mutator for totalRecipeCalories attribute
     * @param totalRecipeCalories the totalRecipeCalories to set
     */
    public void setTotalRecipeCalories(double totalRecipeCalories) {
        this.totalRecipeCalories = totalRecipeCalories;
    }      
    
    // create constructors for recipe objects
    
    /**
     * basic recipe constructor with no parameters
     */
    public Recipe() {
        this.recipeName = "";
        this.servings = 0;
        this.recipeIngredients = new ArrayList();
        this.totalRecipeCalories = 0.0;
    }
    
    /**
     * recipe constructor with necessary parameters
     * @param recipeName the name of the recipe
     * @param servings the serving size of the recipe
     * @param recipeIngredients a list of ingredients in the recipe
     */
    public Recipe(String recipeName, int servings, ArrayList<Ingredient> recipeIngredients) {
        this.recipeName = recipeName;
        this.servings = servings;
        this.recipeIngredients = recipeIngredients;
        int i;
        for (i = 0; i < recipeIngredients.size(); i = i + 1) {
            this.totalRecipeCalories = this.totalRecipeCalories + this.recipeIngredients.get(i).getIngredientAmount() * this.recipeIngredients.get(i).getCaloriesPerUnit();
        }
    }
    
    // methods to print recipe details
    
    /**
     * method to print the details of a recipe
     */
    public void printRecipe() {
        // initialize and calculate the calories in a single serving
        double singleServingCalories;
        singleServingCalories = totalRecipeCalories / servings;
        
        // print the recipe name and serving size
        System.out.println("\nRecipe: " + recipeName);
        System.out.println("Serves: " + servings);
        
        // print the ingredients
        System.out.println("Ingredients:");
        
        int i;
        // loop through each ingredient in the array list
        // print the amount, unit measurement, and name of each ingredient
        for (i = 0; i < recipeIngredients.size(); i = i + 1) {
            System.out.print(recipeIngredients.get(i).getIngredientAmount() + " ");
            System.out.print(recipeIngredients.get(i).getUnitMeasurement() + " of ");
            System.out.println(recipeIngredients.get(i).getNameOfIngredient());
        }
        
        // print the amount of calories in a single serving
        System.out.println("Each serving has " + singleServingCalories + " Calories.");
    }
    
    /**
     * method to print a recipe with an adjusted serving size
     * @param recipeServings the adjusted serving size for the recipe
     */
    public void printModifiedRecipe(int recipeServings) {
        // initialize and calculate the calories in a single serving
        double singleServingCalories;
        singleServingCalories = totalRecipeCalories / servings;
        
        // print the recipe name and serving size
        System.out.println("\nRecipe: " + recipeName);
        System.out.println("Serves: " + recipeServings);
        
        // print the ingredients
        System.out.println("Ingredients:");
        
        int i;
        // loop through each ingredient in the array list
        // print the amount, unit measurement, and name of each ingredient
        // the amount is multiplied by the desired serving size and divided by the original serving size
        // the resulting amount is how much of the ingredient would be required to make the desired servings
        for (i = 0; i < recipeIngredients.size(); i = i + 1) {
            System.out.print((recipeIngredients.get(i).getIngredientAmount() * recipeServings / servings) + " ");
            System.out.print(recipeIngredients.get(i).getUnitMeasurement() + " of ");
            System.out.println(recipeIngredients.get(i).getNameOfIngredient());
        }
        
        // print the amount of calories in a single serving
        System.out.println("Each serving has " + singleServingCalories + " Calories.");
    }
    
    /**
     * method to create a new recipe from user input
     * @return newRecipe - a completed Recipe object for a list of recipes
     */
    public Recipe createNewRecipe() {
        
        //initialize temporary attributes
        String tempRecipeName;
        int tempServings;
        ArrayList<Ingredient> tempRecipeIngredients;
        double tempTotalRecipeCalories = 0.0;
        
        // get valid recipe name from user
        System.out.println("\nPlease enter the recipe name: ");
        tempRecipeName = Validation.getValidRecipeName();
        
        // get valid serving size from user
        System.out.println("\nPlease enter the number of servings in your " + tempRecipeName + " recipe: ");
        tempServings = Validation.getValidServings();
        
        // get valid list of ingredients from user
        System.out.println("\n-----Ingredients in " + tempServings + " servings of " + tempRecipeName + "-----");
        tempRecipeIngredients = Validation.getValidIngredientList();
        
        // calculate total calories in the recipe
        // multiply each ingredient's amount and calories per unit and add them all together
        int i;
        for (i = 0; i < recipeIngredients.size(); i = i + 1) {
            tempTotalRecipeCalories = tempTotalRecipeCalories + tempRecipeIngredients.get(i).getIngredientAmount() * tempRecipeIngredients.get(i).getCaloriesPerUnit();
        }
        
        // create new recipe object from parameterized constructor
        Recipe newRecipe = new Recipe(tempRecipeName, tempServings, tempRecipeIngredients);
        
        // return the new recipe obejct
        return newRecipe;
    }
}
