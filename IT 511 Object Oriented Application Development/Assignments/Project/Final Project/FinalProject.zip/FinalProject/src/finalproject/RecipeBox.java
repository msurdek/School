package finalproject;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * RecipeBox - class to store recipes and provide main menu to user
 *
 * @author michaelsurdek_snhu
 */
public class RecipeBox {

    // initialize recipebox class attributes
    private ArrayList<Recipe> listOfRecipes = new ArrayList(); // an array list of recipes

    // create accessor and mutator methods for each attribute
    
    /**
     * accessor for listOfRecipes attribute
     * @return the listOfRecipes
     */
    public ArrayList<Recipe> getListOfRecipes() {
        return listOfRecipes;
    }

    /**
     * mutator for listOfRecipes attribute
     * @param listOfRecipes the listOfRecipes to set
     */
    public void setListOfRecipes(ArrayList<Recipe> listOfRecipes) {
        this.listOfRecipes = listOfRecipes;
    }
    
    // create constructors for recipebox objects
    
    /**
     * basic recipebox constructor with no parameters
     */
    public RecipeBox() {
        this.listOfRecipes = new ArrayList();
    }
    
    /**
     * recipebox constructor with necessary parameters
     * @param recipes a list of recipes for the collection
     */
    public RecipeBox(ArrayList<Recipe> recipes) {
        this.listOfRecipes = recipes;
    }

    /**
     * method to print recipe details
     * @param recipeName the name of the recipe to print
     */
    public void printAllRecipeDetails(String recipeName) {
        // loop through list of recipes to find the one that the user selected 
        for (int i = 0; i < listOfRecipes.size(); i = i + 1) {
            // if there is a match, print all details of that recipe
            if (listOfRecipes.get(i).getRecipeName().equals(recipeName)) {
                listOfRecipes.get(i).printRecipe();
            }
        }
    }
    
    /**
     * method to print recipe details based on a custom serving size
     * @param recipeName the name of the recipe to print
     * @param recipeServings the adjusted serving size of the recipe
     */
    public void printModifiedRecipeDetails(String recipeName, int recipeServings) {
        // loop through list of recipes to find the one that the user selected 
        for (int i = 0; i < listOfRecipes.size(); i = i + 1) {
            // if there is a match, print details of the recipe based on the modified serving size
            if (listOfRecipes.get(i).getRecipeName().equals(recipeName)) {
                listOfRecipes.get(i).printModifiedRecipe(recipeServings);
            }
        }
    }
    
    /**
     * method to print the names of all recipe in the collection
     */
    public void printAllRecipeNames() {
        // loop through the list of recipes and print the name of each
        for (int i = 0; i < listOfRecipes.size(); i = i + 1) {
            System.out.println(listOfRecipes.get(i).getRecipeName());
        }
    }
    
    /**
     * method to add a recipe to the collection
     */
    public void addRecipe() {
        // create a new recipe from scratch and add it to the collection
        Recipe tempRecipe = new Recipe().createNewRecipe();
        listOfRecipes.add(tempRecipe);
    }
    
    /**
     * method to edit a recipe in the collection
     * @param recipeName the name of the recipe to edit
     */
    public void editRecipe(String recipeName) {
        // loop through list of recipes to find the one that the user selected 
        for (int i = 0; i < listOfRecipes.size(); i = i + 1) {
            // if there is a match, replace the recipe with new details from the user
            if (listOfRecipes.get(i).getRecipeName().equals(recipeName)) {
                Recipe tempRecipe = new Recipe().createNewRecipe();
                listOfRecipes.set(i, tempRecipe);
            }
        }
    }
    
    /**
     * method to delete a recipe from the collection
     * @param recipeName the name of the recipe to delete
     */
    public void deleteRecipe(String recipeName) {
        // loop through list of recipes to find the one that the user selected 
        for (int i = 0; i < listOfRecipes.size(); i = i + 1) {
            // if there is a match, remove that recipe from the collection
            if (listOfRecipes.get(i).getRecipeName().equals(recipeName)) {
                listOfRecipes.remove(i);
            }
        }
    }
    
    /**
     * main method to run the recipeBox driver
     * @param args for main method
     */
    public static void main(String[] args) {
        
        // initialize recipeBox fields
        RecipeBox myRecipeBox = new RecipeBox();
        int input = 0;
        
        // until the user enters 7, the menu will be printed
        while (input != 7) {
            
            // ask the user for an integer between 1 and 7
            input = Validation.getValidMenuInput();

            switch (input) {
                // if user enters 1, they will be prompted to enter details for a new recipe
                case 1:
                    System.out.println("\n-----New recipe-----");
                    myRecipeBox.addRecipe();
                    break;
                // if user enters 2, they will be asked for the recipe name and then prompted to re-enter the details if it exists
                case 2:
                    {
                        Scanner menuScnr = new Scanner(System.in);
                        // get the name of the recipe to print from user
                        System.out.println("\nWhich recipe?");
                        String selectedRecipeName = menuScnr.nextLine();
                        // edit the selected recipe
                        System.out.println("\n-----Editing " + selectedRecipeName + "-----");
                        myRecipeBox.editRecipe(selectedRecipeName);
                        break;
                    }
                // if user enters 3, they will be asked for the recipe name and it will be deleted if it exists 
                case 3:
                    {
                        Scanner menuScnr = new Scanner(System.in);
                        // get the name of the recipe to print from user
                        System.out.println("\nWhich recipe?");
                        String selectedRecipeName = menuScnr.nextLine();
                        // delete the selected recipe
                        System.out.println("\n-----Deleting " + selectedRecipeName + "-----");
                        myRecipeBox.deleteRecipe(selectedRecipeName);
                        break;
                    }
                // if the user enters 4, all recipe names in the collection are printed
                case 4:
                    System.out.println("\n-----List of recipes-----");
                    // print the names of all recipes
                    myRecipeBox.printAllRecipeNames();
                    break;
                // if user enters 5, they will be asked for the recipe name and it's details will be printed if it exists
                case 5:
                    {
                        Scanner menuScnr = new Scanner(System.in);
                        // get the name of the recipe to print from user
                        System.out.println("\nWhich recipe?");
                        String selectedRecipeName = menuScnr.nextLine();
                        // print details of the selected recipe
                        System.out.println("\n-----Recipe details-----");
                        myRecipeBox.printAllRecipeDetails(selectedRecipeName);
                        break;
                    }
                // if user enters 6, a modified recipe will be printed based on further input
                case 6:
                    {
                        Scanner menuScnr = new Scanner(System.in);
                        // get the name of the recipe to print from user
                        System.out.println("\nWhich recipe?");
                        String selectedRecipeName = menuScnr.nextLine();
                        // get the new serving size for this recipe
                        System.out.println("\nPlease enter the modified number of servings of " + selectedRecipeName + ": ");
                        int selectedRecipeServings = Validation.getValidServings();
                        // print details of the selected recipe based on an adjusted serving size
                        System.out.println("\n-----Recipe details (modified)-----");
                        myRecipeBox.printModifiedRecipeDetails(selectedRecipeName, selectedRecipeServings);
                        break;
                    }
                // if user enters 7, the while loop condition becomes false and menu is exited
                case 7:
                    System.out.println("\n-----Exiting-----");
                    break;
                // default case, won't be reached because input is limited to integers 1-7
                default:
                    break;
            }
        }
    }
}