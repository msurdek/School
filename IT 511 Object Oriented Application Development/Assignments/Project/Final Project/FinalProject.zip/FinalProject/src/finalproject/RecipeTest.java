package finalproject;

import java.util.ArrayList;

/**
 * RecipeTest - class to test the various construction methods of a recipe object 
 *
 * @author michaelsurdek_snhu
 */
public class RecipeTest {

    /**
    * method to create recipes in 3 different ways
    * 1. through mutators
    * 2. through a constructor
    * 3. through user input
    */
    public static void RecipeTest() {

        // initialize first recipe
        Recipe myFirstRecipe = new Recipe();

        // set first ingredient details
        ArrayList<Ingredient> recipeIngredients = new ArrayList();
        String ingredientName = "Noodles";
        Ingredient tempIngredient = new Ingredient();
        tempIngredient.setNameOfIngredient(ingredientName);
        tempIngredient.setUnitMeasurement("cups");
        tempIngredient.setIngredientAmount(5);
        tempIngredient.setCaloriesPerUnit(30);
        
        // add ingredient to first array list
        recipeIngredients.add(tempIngredient);

        // set first recipe attributes through mutators
        myFirstRecipe.setRecipeName("Ramen");
        myFirstRecipe.setServings(2);
        myFirstRecipe.setRecipeIngredients(recipeIngredients);
        myFirstRecipe.setTotalRecipeCalories(150);

        // initiate second recipe
        // first, set second ingredient details
        ArrayList<Ingredient> recipeIngredientsTwo = new ArrayList();
        String ingredientNameTwo = "Anchovies";
        Ingredient tempIngredientTwo = new Ingredient();
        tempIngredientTwo.setNameOfIngredient(ingredientNameTwo);
        tempIngredientTwo.setUnitMeasurement("ounces");
        tempIngredientTwo.setIngredientAmount(8);
        tempIngredientTwo.setCaloriesPerUnit(40);
        recipeIngredientsTwo.add(tempIngredientTwo);

        // set second recipe attributes through constructor
        Recipe mySecondRecipe = new Recipe("Pizza", 2, recipeIngredientsTwo);

        // print details of both recipes
        myFirstRecipe.printRecipe();
        mySecondRecipe.printRecipe();
        
        // create third recipe from user input
        Recipe myThirdRecipe = new Recipe().createNewRecipe();
        // print details of third recipe
        myThirdRecipe.printRecipe();
    }
}
