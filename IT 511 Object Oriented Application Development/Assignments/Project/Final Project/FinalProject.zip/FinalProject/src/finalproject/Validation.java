package finalproject;

import java.util.Scanner;
import java.util.ArrayList;

/**
 * Validation - class to ensure proper user input throughout the recipe collection program
 *
 * @author michaelsurdek_snhu
 */
public class Validation {
    
    /**
     * static validation method for the name of the recipe
     * @return recipeName - the name of the recipe
     */
    public static String getValidRecipeName() {
        // initialize attributes
        String recipeName = "";
        boolean keepGoing = true;
        
        // prompt the user until they enter a recipe name
        do {
            Scanner scnr = new Scanner(System.in);
            // ensure that the scanner has user input
            if (scnr.hasNextLine()) {
                recipeName = scnr.nextLine();
            } 
            // ensure that the user actually entered a string
            if (recipeName.length() >= 1) {
                keepGoing = false;
            } else {
                System.out.println("Nothing was entered. Please try again.");
            }
        } while (keepGoing);
        
        // return the valid recipe name
        return recipeName;
    }
    
    /**
     * static validation method for the serving size of the recipe
     * @return servings - the serving size of the recipe
     */
    public static int getValidServings() {
        // initialize attributes
        int servings = 0;
        boolean keepGoing = true;
        
        // prompt the user until they enter a serving size
        do {
            Scanner scnr = new Scanner(System.in);
            // ensure that the scanner has integer input
            if (scnr.hasNextInt()) {
                servings = scnr.nextInt();
                keepGoing = false;
            } else {
                System.out.println("That is not an integer. Please try again.");
            }
        } while (keepGoing);
        
        // return the valid serving size
        return servings;
    }

    /**
     * static validation method for the name of the ingredient
     * @return ingredientName - the name of an ingredient in the recipe
     */
    public static String getValidIngredientName() {
        // initialize attributes
        String ingredientName = "";
        boolean keepGoing = true;
        
        // prompt the user until they enter an ingredient name
        do {
            Scanner scnr = new Scanner(System.in);
            // ensure that the scanner has user input
            if (scnr.hasNextLine()) {
                ingredientName = scnr.nextLine();
            } 
            // ensure that the user actually entered a string
            if (ingredientName.length() >= 1) {
                keepGoing = false;
            } else {
                System.out.println("Nothing was entered. Please try again.");
            }
        } while (keepGoing);
        
        // return the valid ingredient name
        return ingredientName;
    }
    
    /**
     * static validation method for the measurement type of the ingredient
     * @return unitMeasurement - the unit of measurement of an ingredient in the recipe
     */
    public static String getValidUnitMeasurement() {
        // initialize attributes
        String unitMeasurement = "";
        boolean keepGoing = true;
        
        // prompt the user until they enter a measurement type
        do {
            Scanner scnr = new Scanner(System.in);
            // ensure that the scanner has user input
            if (scnr.hasNextLine()) {
                unitMeasurement = scnr.nextLine();
            } 
            // ensure that the user actually entered a string
            if (unitMeasurement.length() >= 1) {
                keepGoing = false;
            } else {
                System.out.println("Nothing was entered. Please try again.");
            }
        } while (keepGoing);
        
        // return the valid measurement type
        return unitMeasurement;
    }
    
    /**
     * static validation method for the amount of the ingredient
     * @return ingredientAmount - the number of units of an ingredient in the recipe
     */
    public static double getValidIngredientAmount() {
        // initialize attributes
        double ingredientAmount = 0.0;
        boolean keepGoing = true;
        
        // prompt the user until they enter an ingredient amount
        do {
            Scanner scnr = new Scanner(System.in);
            // ensure that the scanner has numerical input
            if (scnr.hasNextDouble()) {
                ingredientAmount = scnr.nextDouble();
                keepGoing = false;
            } else {
                System.out.println("That is not a number. Please try again.");
            }
        } while (keepGoing);
        
        // return the valid ingredient amount
        return ingredientAmount;
    }
    
    /**
     * static validation method for the calories per unit of the ingredient
     * @return caloriesPerUnit - the calories in each unit of an ingredient in the recipe
     */
    public static double getValidCaloriesPerUnit() {
        // initialize attributes
        double caloriesPerUnit = 0.0;
        boolean keepGoing = true;
        
        // prompt the user until they enter a number of calories per unit
        do {
            Scanner scnr = new Scanner(System.in);
            // ensure that the scanner has numerical input
            if (scnr.hasNextDouble()) {
                caloriesPerUnit = scnr.nextDouble();
                keepGoing = false;
            } else {
                System.out.println("That is not a number. Please try again.");
            }
        } while (keepGoing);
        
        // return the valid calories per unit
        return caloriesPerUnit;
    }
       
    /**
     * static validation method to get a list of ingredients for the recipe
     * @return ingredientList - the list of ingredients in the recipe
     */
    public static ArrayList<Ingredient> getValidIngredientList() {
        // initialize attributes
        ArrayList<Ingredient> ingredientList = new ArrayList();
        String reply = "";
        boolean keepGoing = true;
        
        // create new ingredients until the user indicates there are no more ingredients to add
        do {
            // create new ingredient from user input
            Ingredient tempIngredient = new Ingredient().createNewIngredient();
            ingredientList.add(tempIngredient);
            
            // prompt the user until they enter 'y' or 'n' to indicate if they have more ingredients to add
            do {
                Scanner scnr = new Scanner(System.in);
                System.out.println("\nDo you have another ingredient to add? (y/n)");
                // ensure that the scanner has user input
                if (scnr.hasNextLine()) {
                    reply = scnr.nextLine(); 
                    // if the user enters 'n', there are no more ingredients to add and both loops are terminated
                    if ((reply.length() == 1) & (reply.charAt(0) == 'n')) {
                        keepGoing = false;
                    }
                }
            } while ((reply.length() != 1) | (reply.charAt(0) != 'y' & reply.charAt(0) != 'n'));
            
        } while (keepGoing);
        
        // return the valid list of ingredients
        return ingredientList;
    }
    
    /**
     * static validation method to print the recipebox driver menu and get user input between 1 and 7
     * @return input - an integer between 1 and 7 for navigating the recipebox driver menu
     */
    public static int getValidMenuInput() {
        // initialize attributes
        int input = 0;
        boolean keepGoing = true;
        
        // prompt the user until they enter an integer between 1 and 7
        do {
            Scanner scnr = new Scanner(System.in);
            System.out.println("\n-----Menu-----\n\n" + "1. Add Recipe\n" + "2. Edit Recipe\n" + "3. Delete Recipe\n" + "\n4. Print All Recipe Names\n" + "5. Print Recipe Details\n" + "6. Print Modified Recipe Details\n" + "\n7. Exit\n" + "\nPlease select a menu item:");
            // ensure that the scanner has integer input
            if (scnr.hasNextInt()) {
                input = scnr.nextInt();
            } else {
                System.out.println("\nThat is not an integer. Please try again.");
            }
            // ensure that the user input is between 1 and 7
            if (input >= 1 & input <= 7) {
                keepGoing = false;
            } else {
                System.out.println("\nPlease enter a menu item (1-5):");
            }
        } while (keepGoing);
        
        // return the valid input
        return input;
    }
    
}
