/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *
 * @author michaelsurdek_snhu
 */

package FinalProjectMilestoneOne;

import java.util.Scanner;

public class Ingredient {

    public static void main(String[] args) {
        // initialize the scanner
        Scanner scnr = new Scanner(System.in);

        // initialize variables to store each ingredient's attributes
        String nameOfIngredient = "";           // the name of the ingredient as a seqeuence of characters
        int numberOfCups = 0;                   // the number of cups as a positive integer between 1 and 100
        final int MAX_CUPS = 100;               // the maximum number of cups of an ingredient that the program can accept
        double numberOfCaloriesPerCup = 0.0;    // the number of calories in a cup of the ingredient as a floating point number
        double totalCalories = 0.0;             // the total calories of the ingredient as a floating point number
        
        // ask user for ingredient name
        System.out.println("Please enter the name of the ingredient: ");
        nameOfIngredient = scnr.nextLine();
        
        // verify the user entered an ingredient name
        if (nameOfIngredient.length() > 0) {
            System.out.println(nameOfIngredient + " is a valid ingredient name.");
        } 
        
        // if nothing entered, allow another try
        else {
            System.out.println("Error: Nothing entered. Try again.");
            System.out.println("Please enter the name of the ingredient: ");
            nameOfIngredient = scnr.nextLine();
            
            // verify name again
            if (nameOfIngredient.length() > 0) {
                System.out.println(nameOfIngredient + " is a valid ingredient name.");
            } 
            
            // if nothing entered again, print error and exit program
            else {
                System.out.println("Error: Nothing entered. Sorry you are out of attempts.");
                System.exit(0);
            }
        }
        
        // ask the user for the number of cups in the ingredient
        System.out.println("Please enter the number of cups of " + nameOfIngredient + " that we'll need (between 1 and 100): ");
        
        // verify that the input is an integer
        if (scnr.hasNextInt()) {
            numberOfCups = scnr.nextInt();
            
            // if number of cups is an integer between 1 and 100, else branch is not entered
            if ((numberOfCups >= 1) & (numberOfCups <= MAX_CUPS)) {
                System.out.println(numberOfCups + " is a valid number of cups!");
            }
            
            // else branch prints whether the number of cups is less than 1 or greater than 100 then asks for a second input
            else {
                if (numberOfCups < 1){
                    System.out.println(numberOfCups + " is less than 1.");
                }
                else {
                    System.out.println(numberOfCups + " is greater than 100.");
                }
                System.out.println("Please enter another number of cups between 1 and 100.");
                numberOfCups = scnr.nextInt();
                
                // the final branch prints whether the second input is a valid integer
                // if it is not, the user is informed they are out of attempts
                if ((numberOfCups >= 1) & (numberOfCups <= 100)) {
                    System.out.println(numberOfCups + " is a valid number of cups!");
                }
                else {
                    System.out.println(numberOfCups + " is not a valid number of cups! Sorry you are out of attempts.");
                    System.exit(0);
                }
            }
        }
        
        // if not an integer, print error and exit program
        else {
            System.out.println("Error: That is not a number. Sorry you are out of attempts.");
            System.exit(0);
        }

        // ask the user for the number of calories per cup of this ingredient
        System.out.println("Please enter the number of calories per cup of " + nameOfIngredient + ": ");

        // verify that the input is a floating point number
        if (scnr.hasNextFloat()) {
            numberOfCaloriesPerCup = scnr.nextFloat();
        }
        
        // if not a floating point number, print error and exit program
        else {
            System.out.println("Error: That is not a number. Sorry you are out of attempts.");
            System.exit(0);
        }
                
        // calculate total calories in the ingredient
        // multiply the number of cups of the ingredient by the calories per cup
        totalCalories = numberOfCups * numberOfCaloriesPerCup;
        
        // print summary of ingredient details
        System.out.println(numberOfCups + " cups of " + nameOfIngredient + " has " + totalCalories + " calories.");
    }
}