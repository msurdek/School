/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalprojectmilestonetwo;

import java.util.Scanner;

/**
 * Ingredient - class to store details of ingredients that make up a recipe object 
 * 
 * @author michaelsurdek_snhu
 */

public class Ingredient {
    
    String nameOfIngredient = "";           // the name of the ingredient as a seqeuence of characters
    String unitMeasurement = "";            // the type of measurement for the ingredient (cups, ounces, etc.)
    double ingredientAmount = 0.0;          // the amount of cups/ounces required
    double caloriesPerUnit = 0.0;           // the number of calories in a unit of the ingredient
    double totalCalories = 0.0;             // the total calories of the ingredient as a floating point number

    public Ingredient() {
    }

    public Ingredient(String nameOfIngredient, String unitMeasurement, double ingredientAmount, double caloriesPerUnit) {
        this.nameOfIngredient = nameOfIngredient;
        this.unitMeasurement = unitMeasurement;
        this.ingredientAmount = ingredientAmount;
        this.caloriesPerUnit = caloriesPerUnit;
        this.totalCalories = ingredientAmount * caloriesPerUnit;
    }
    
    /**
     * @return the nameOfIngredient
     */
    public String getNameOfIngredient() {
        return nameOfIngredient;
    }

    /**
     * @param nameOfIngredient the nameOfIngredient to set
     */
    public void setNameOfIngredient(String nameOfIngredient) {
        this.nameOfIngredient = nameOfIngredient;
    }

    /**
     * @return the unitMeasurement
     */
    public String getUnitMeasurement() {
        return unitMeasurement;
    }

    /**
     * @param unitMeasurement the unitMeasurement to set
     */
    public void setUnitMeasurement(String unitMeasurement) {
        this.unitMeasurement = unitMeasurement;
    }

    /**
     * @return the ingredientAmount
     */
    public double getIngredientAmount() {
        return ingredientAmount;
    }

    /**
     * @param ingredientAmount the ingredientAmount to set
     */
    public void setIngredientAmount(double ingredientAmount) {
        this.ingredientAmount = ingredientAmount;
    }

    /**
     * @return the caloriesPerUnit
     */
    public double getCaloriesPerUnit() {
        return caloriesPerUnit;
    }

    /**
     * @param caloriesPerUnit the caloriesPerUnit to set
     */
    public void setCaloriesPerUnit(double caloriesPerUnit) {
        this.caloriesPerUnit = caloriesPerUnit;
    }

    /**
     * @return the totalCalories
     */
    public double getTotalCalories() {
        return totalCalories;
    }

    /**
     * @param totalCalories the totalCalories to set
     */
    public void setTotalCalories(double totalCalories) {
        this.totalCalories = totalCalories;
    }
    
    public void addNewIngredient() {
        
        // initialize the scanner
        Scanner scnr = new Scanner(System.in);
        
        // get ingredient name, unit of measurement, ingredient amount, and calories per unit from user
        System.out.println("Please enter the name of an ingredient: ");
        this.nameOfIngredient = scnr.nextLine();
        
        System.out.println("Please enter the type of measure of " + nameOfIngredient + " that the recipe uses: ");
        System.out.println("Possible types of measurements include cups, ounces, teaspoons, etc.");
        this.unitMeasurement = scnr.nextLine();

        System.out.println("Please enter the amount of " + unitMeasurement + " of " + nameOfIngredient + " that we'll need: ");
        this.ingredientAmount = scnr.nextDouble();
        
        System.out.println("Please enter the number of calories per " + unitMeasurement + " of " + nameOfIngredient + ": ");
        this.caloriesPerUnit = scnr.nextDouble();
        
        // calculate total calories in the ingredient
        // multiply the number of cups of the ingredient by the calories per cup
        this.totalCalories = ingredientAmount * caloriesPerUnit;
    }
    
}