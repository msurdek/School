/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalprojectmilestonetwo;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * Recipe - class to store recipe details
 *        - includes methods to create new recipes, set details, and print the recipe
 * 
 * @author michaelsurdek_snhu
 */
public class Recipe {

    // declare recipe class attributes
    String recipeName;                      // name of the recipe
    int servings;                           // number of people the recipe can serve
    ArrayList<Ingredient> recipeIngredients;    // list of ingredients in the recipe
    double totalRecipeCalories;             // sum of calories from all ingredients
    
    // create accessor and mutator for each attribute
    /**
     * @return the recipeName
     */
    public String getRecipeName() {
        return recipeName;
    }

    /**
     * @param recipeName the recipeName to set
     */
    public void setRecipeName(String recipeName) {
        this.recipeName = recipeName;
    }

    /**
     * @return the servings
     */
    public int getServings() {
        return servings;
    }

    /**
     * @param servings the servings to set
     */
    public void setServings(int servings) {
        this.servings = servings;
    }

    /**
     * @return the recipeIngredients
     */
    public ArrayList<Ingredient> getRecipeIngredients() {
        return recipeIngredients;
    }

    /**
     * @param recipeIngredients the recipeIngredients to set
     */
    public void setRecipeIngredients(ArrayList<Ingredient> recipeIngredients) {
        this.recipeIngredients = recipeIngredients;
    }

    /**
     * @return the totalRecipeCalories
     */
    public double getTotalRecipeCalories() {
        return totalRecipeCalories;
    }

    /**
     * @param totalRecipeCalories the totalRecipeCalories to set
     */
    public void setTotalRecipeCalories(double totalRecipeCalories) {
        this.totalRecipeCalories = totalRecipeCalories;
    }      
    
    // create basic constructor
    public Recipe() {
        this.recipeName = "";
        this.servings = 0;
        this.recipeIngredients = new ArrayList();
        this.totalRecipeCalories = 0.0;
    }
    
    // create constructor with parameters
    public Recipe(String recipeName, int servings,
            ArrayList<Ingredient> recipeIngredients, double totalRecipeCalories) {
        this.recipeName = recipeName;
        this.servings = servings;
        this.recipeIngredients = recipeIngredients;
        this.totalRecipeCalories = totalRecipeCalories;
    }
    
    // method to print recipe details
    public void printRecipe() {
        double singleServingCalories;
        singleServingCalories = totalRecipeCalories / servings;
        
        System.out.println("Recipe: " + recipeName);
        System.out.println("Serves: " + servings);
        System.out.println("Ingredients:");
        
        int i;
        for (i = 0; i < recipeIngredients.size(); i = i + 1) {
            System.out.print(recipeIngredients.get(i).getIngredientAmount() + " ");
            System.out.print(recipeIngredients.get(i).getUnitMeasurement() + " of ");
            System.out.println(recipeIngredients.get(i).getNameOfIngredient());
        }
        
        System.out.println("Each serving has " + singleServingCalories + " Calories.");
    }
    
    /*
    * PSUEDOCODE FOR CUSTOM METHOD TO PRINT RECIPE WITH VARIOUS SERVING SIZES
    *
    * get desired serving size from user
    *
    * print recipe name
    * print desired serving size
    * print ingredients
    *   - divide ingredient amount by original serving size
    *   - multiply above amount by desired serving size
    * 
    * print single serving calories
    *
    *
    */
    
    public static Recipe createNewRecipe() {
        // initialize recipe attributes to default values
        String recipeName = "";
        int servings = 0;
        double totalRecipeCalories = 0.0;
        ArrayList<Ingredient> recipeIngredients = new ArrayList();
        boolean addMoreIngredients = true;
        
        Scanner scnr = new Scanner(System.in);
        
        // ask user for the name of the recipe
        recipeName = Validation.getValidRecipeName();
        
        // ask the user how many people the recipe serves
        servings = Validation.getValidServings();
        
        // until the user inputs "end", ask for the ingredient name, measurement amount, and calories per unit
        
        do {
            Ingredient newIngredient = new Ingredient();
            newIngredient.addNewIngredient();
            
            recipeIngredients.add(newIngredient);
            
            System.out.println("Do you have another ingredient to add? (y/n)");
            Scanner scnrReply = new Scanner(System.in);
            String reply = scnrReply.nextLine();
            
            if ((reply.length() == 1) & (reply.charAt(0) == 'n')) {
                addMoreIngredients = false;
            }
        } while (addMoreIngredients);
        
        //calculate total calories in the recipe
        int i;
        for (i = 0; i < recipeIngredients.size(); i = i + 1) {
            totalRecipeCalories = totalRecipeCalories + recipeIngredients.get(i).getIngredientAmount() * recipeIngredients.get(i).getCaloriesPerUnit();
        }
        
        // create new recipe based on user input and print the details
        Recipe recipe1 = new Recipe(recipeName, servings, recipeIngredients, totalRecipeCalories);
        recipe1.printRecipe();
        
        return recipe1;
    }
}
