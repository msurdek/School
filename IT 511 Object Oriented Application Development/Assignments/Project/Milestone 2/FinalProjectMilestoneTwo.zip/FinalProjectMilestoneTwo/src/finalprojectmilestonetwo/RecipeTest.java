/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalprojectmilestonetwo;

/**
 *
 * RecipeTest - test harness to verify execution of recipe constructors and createNewRecipe() method
 * 
 * @author michaelsurdek_snhu
 */
import java.util.ArrayList;

public class RecipeTest {

    public static void main(String[] args) {

        // initialize first recipe
        Recipe myFirstRecipe = new Recipe();

        // set first ingredient details
        ArrayList<Ingredient> recipeIngredients = new ArrayList();
        String ingredientName = "Noodles";
        Ingredient tempIngredient = new Ingredient();
        tempIngredient.setNameOfIngredient(ingredientName);
        tempIngredient.setUnitMeasurement("cups");
        tempIngredient.setIngredientAmount(5);
        // add ingredient to first array list
        recipeIngredients.add(tempIngredient);

        // set first recipe attributes through mutators
        myFirstRecipe.setRecipeName("Ramen");
        myFirstRecipe.setServings(2);
        myFirstRecipe.setRecipeIngredients(recipeIngredients);
        myFirstRecipe.setTotalRecipeCalories(150);

        // initiate second recipe
        // first, set second ingredient details
        ArrayList<Ingredient> recipeIngredientsTwo = new ArrayList();
        String ingredientNameTwo = "Anchovies";
        Ingredient tempIngredientTwo = new Ingredient();
        tempIngredientTwo.setNameOfIngredient(ingredientNameTwo);
        tempIngredientTwo.setUnitMeasurement("ounces");
        tempIngredientTwo.setIngredientAmount(8);
        recipeIngredientsTwo.add(tempIngredientTwo);

        // set second recipe attributes through constructor
        Recipe mySecondRecipe = new Recipe("Pizza", 2, recipeIngredientsTwo, 300);

        // print details of both recipes
        myFirstRecipe.printRecipe();
        mySecondRecipe.printRecipe();
        
        // create third recipe from user input
        // FIXME:: not sure why this doesnt seem to be executing in the test harness
        // tried as static and non-static method in recipe class
        Recipe myThirdRecipe = Recipe.createNewRecipe();
        myThirdRecipe.printRecipe();
    }
}
