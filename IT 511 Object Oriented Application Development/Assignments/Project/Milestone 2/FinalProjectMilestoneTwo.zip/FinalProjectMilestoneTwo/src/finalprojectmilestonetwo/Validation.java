/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalprojectmilestonetwo;

import java.util.Scanner;
/**
 * Validation - class to ensure proper user input for each variable
 * FIXME:: add validation methods for ingredient attributes
 * @author michaelsurdek_snhu
 */
public class Validation {
    
    // validation method for the name of the recipe
    public static String getValidRecipeName() {
        Scanner scnr = new Scanner(System.in);
        String recipeName;
        System.out.println("Please enter the recipe name: ");
        recipeName = scnr.nextLine();
        return recipeName;
    }
    
    // validation method for the serving size of the recipe
    public static int getValidServings() {
        Scanner scnr = new Scanner(System.in);
        int servings;
        System.out.println("Please enter the recipe name: ");
        servings = scnr.nextInt();
        return servings;
    }
}
